<template lang="pug">
.separador-container
  .separador
</template>

<script>
export default {
  name: 'Separador',
}
</script>

<style lang="sass"></style>
