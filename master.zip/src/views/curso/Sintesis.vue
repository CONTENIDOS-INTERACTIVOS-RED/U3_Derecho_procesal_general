<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up") La Unidad 3: Procesos en el Código General del Proceso, ofrece una visión estructurada de las clases de procesos contempladas en el ordenamiento procesal civil colombiano, así como de las etapas que los integran. Esta unidad profundiza en los procesos declarativos, ejecutivos, de jurisdicción voluntaria y de liquidación de sociedad conyugal o patrimonial, resaltando sus particularidades y la normativa que los regula. Además, se exploran los principios que rigen la actividad probatoria, los medios de prueba reconocidos por la Ley y las decisiones judiciales que pueden adoptarse dentro del proceso.

      p(data-aos="fade-up").mb-5 Este enfoque permite a los estudiantes comprender el funcionamiento del sistema procesal civil, identificar los momentos claves en los que intervienen las partes, y reconocer los recursos procesales como mecanismos de control y defensa. Con ello, se fortalece la formación jurídica práctica, necesaria para una actuación profesional eficiente y conforme al debido proceso.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
