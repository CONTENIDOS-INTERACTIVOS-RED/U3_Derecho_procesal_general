<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'2. La prueba en el proceso civil'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    .bg-color-3.mb-5(data-aos="fade-up")
      .row.justify-content-center.align-items-center
        .col-lg
          .p-4
            p.mb-0(data-aos="fade-down") En el ámbito del Derecho Procesal Civil, la prueba representa el núcleo esencial del proceso judicial, pues es a través de ella que se establece la verdad jurídica de los hechos en disputa. La afirmación de derechos no es suficiente por sí sola. Quien alega debe probar, y esa demostración debe hacerse bajo las reglas y principios establecidos en el Código General del Proceso colombiano.       
        .col-lg-auto
          figure
            img(src='@/assets/curso/temas/26.png', alt='')       


    p(data-aos="fade-down") Sin prueba, no hay convicción judicial ni sentencia justa. El proceso probatorio, por tanto, no es un simple trámite, sino la herramienta a través de la cual el juez puede pasar del plano de las afirmaciones, al de las certezas procesales que sustentarán su decisión.

    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/27.png", data-aos="zoom-in")        
      .col-lg-8
        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/28.svg")
            .col-lg
              p.mb-0 En el proceso civil, donde muchas veces no existen pruebas preconstituidas, y las partes tienen el deber de demostrar lo que afirman, el estudio de la prueba se convierte en un eje central de formación jurídica. Aprender a diferenciar entre los distintos tipos de prueba documental, testimonial, pericial, inspección judicial, indicios, entre otras, es fundamental para el buen desarrollo del ejercicio del litigio puesto que se deben tener claro los momentos procesales donde solicitar, practicar y valorar.  
        p(data-aos="fade-down") El Código General del Proceso, en sus Artículos 165 y siguientes, establece no solo el catálogo de medios probatorios admitidos, sino también las reglas sobre su proposición, decreto, práctica y valoración (Muñoz Sabaté, 2018).

        p(data-aos="fade-down") Asimismo, el sistema probatorio se rige por principios fundamentales que garantizan la equidad procesal. Entre ellos se destacan:

    .bg-full-width-1.bg-fondo-1.py-4
      .px-4.px-md-5
        .row.justify-content-center.align-items-stretch.text-center.mb-4
          .col-lg-4.mb-4(data-aos="zoom-in-up")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/29.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center El principio de contradicción
                p.mb-0 Permite que ambas partes intervengan en la práctica y discusión de los medios de prueba.
          .col-lg-4.mb-4(data-aos="zoom-in-down")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/30.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center El principio de concentración
                p.mb-0 Busca que las pruebas se practiquen en una sola audiencia para que el juez tenga una visión integral e inmediata de los hechos. 

          .col-lg-4.mb-4(data-aos="zoom-in-down")
            .custom-image-card-2.h-100.br-1
              img.custom-image-card__image(src="@/assets/curso/temas/31.png" alt="")
              .custom-image-card__text.p-4
                h5.mb-2.text-center El principio de inmediación
                p.mb-0 Según este principio, el juez que practica la prueba es el mismo que debe decidir sobre ella, garantizando así la percepción directa de su contenido y fuerza probatoria.                

    p(data-aos="fade-down") Además, aprender que la prueba cumple dos funciones:

    .row.justify-content-center.mb-5  
      .col-lg-6.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/32.svg")
            .col-lg
              h5 Función cognoscitiva
              p.mb-0 Proporciona al juez elementos para conocer la verdad sobre los hechos relevantes.
      .col-lg-6.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-down")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/33.svg")
            .col-lg
              h5 Función persuasiva
              p.mb-0 Influye en su convicción sobre la responsabilidad de las partes.    

    .bg-full-width.bg-color-6.p-4.mb-5(data-aos="fade-left")
      .px-4
        p.mb-0 En este sentido, no toda prueba tiene el mismo peso ni genera los mismos efectos jurídicos. Algunas pruebas tienen valor legal tasado, como el registro civil en casos de estado civil, mientras que otras son de libre apreciación, como el testimonio o el dictamen pericial, cuyo valor dependerá de criterios de lógica, experiencia y sana crítica.

    .row.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") Un aspecto importante es que la carga de la prueba, indica quién debe probar qué hechos. En los procesos civiles rige el principio, según el cual quien alega debe probar, lo cual tiene implicaciones sustanciales en la estrategia de litigio. Saber distribuir correctamente la carga de la prueba puede ser determinante en el éxito o fracaso de una pretensión. Sin embargo, también existen reglas especiales sobre carga dinámica de la prueba, aplicables cuando una de las partes está en mejores condiciones técnicas o económicas para demostrar un hecho. Este enfoque ha sido acogido por la jurisprudencia constitucional como una herramienta de equilibrio procesal, especialmente en asuntos de consumo, salud o familia.
        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/34.svg")
            .col-lg
              p.mb-0 En conclusión, el estudio de la prueba en el proceso civil, permite dominar una de las áreas más complejas y determinantes del Derecho Procesal, para no solo a identificar los medios probatorios admisibles, sino a construir una teoría del caso sólida, a formular correctamente las solicitudes probatorias, a analizar críticamente las pruebas del contrario y, en especial, a comprender cómo debe el juez valorarlas conforme a los principios de la sana crítica y reglas de la experiencia (Muñoz Sabaté, 2018).   
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/35.png", data-aos="zoom-in")     

    #t_2_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.1] Principios rectores y carga de la prueba

    p(data-aos="fade-down") El proceso probatorio no solo constituye una etapa fundamental del proceso civil, sino que debe desarrollarse bajo el respeto y la aplicación de una serie de principios rectores que garantizan el equilibrio procesal, la igualdad entre las partes y la legitimidad de la decisión judicial. Estos principios orientan tanto al juez como a las partes sobre cómo deben proponerse, practicarse y valorarse las pruebas. Entre ellos destacan:

    .bg-full-width.bg-fondo-slider.mb-0(data-aos="fade-right")
      .p-4.p-md-5
        SlyderA(tipo="b").bg-white
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 El principio de contradicción
              p Es uno de los baluartes del debido proceso. Toda prueba que se pretenda hacer valer en juicio, debe haber sido conocida y debatida por la contraparte. Esto significa que nadie puede ser sorprendido con pruebas que no haya tenido oportunidad de examinar o controvertir. Por ejemplo, si en una audiencia se presenta un documento privado como prueba de una obligación, la parte contraria tiene el derecho de objetarlo, pedir su autenticidad, solicitar contraprueba o incluso rechazarlo por impertinente o falso.        
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/36.png")
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 El principio de pertinencia
              p Establece que solo pueden admitirse aquellas pruebas que se relacionen directamente con los hechos que son objeto del proceso. No todo lo que las partes quieran probar será válido, sino únicamente lo que sea pertinente, útil y conducente para resolver la controversia. Si en un proceso de responsabilidad civil derivada de un accidente de tránsito, se ofrece como prueba un video de la vida privada del demandado, este sería impertinente, pues no guarda relación con el hecho debatido.        
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/37.png")
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 El principio de conducencia
              p Exige que los medios de prueba utilizados sean idóneos para demostrar los hechos alegados. Así, no se puede pretender probar una obligación escrita solo con testigos, si legalmente se exige un documento. En este caso, el juez debe rechazar las pruebas que, aunque puedan tener relación con el hecho, no sean adecuadas para su demostración conforme a la Ley (Gaceta Jurídica, 2014).        
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/38.png")
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 El principio de legalidad
              p Impide que se acepten o valoren pruebas obtenidas por medios ilícitos o en violación a derechos fundamentales. Por ejemplo, no puede admitirse como prueba, una conversación grabada sin consentimiento, en la que no interviene quien la ofrece, o un correo electrónico extraído ilegalmente. Esta garantía protege la integridad del proceso y salvaguarda los derechos fundamentales de las partes, en especial el derecho a la intimidad y al buen nombre.       
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/39.png")
          .row.align-items-center.p-4.p-md-5
            .col-lg-7.mb-3.mb-lg-0
              h5 El principio de necesidad
              p Señala que solo deben practicarse las pruebas indispensables para esclarecer los hechos controvertidos. Esto permite al juez evitar el uso abusivo o dilatorio de medios probatorios innecesarios, lo cual a su vez garantiza un proceso ágil y eficiente. Además, se aplica el principio de igualdad de armas, que busca que las partes cuenten con las mismas posibilidades reales y jurídicas de producir, controvertir y hacer valer pruebas durante el proceso.        
            .col-lg-5.mb-3.mb-lg-0
              figure
                img.img-a.img-t(src="@/assets/curso/temas/40.png")

    .bg-full-width.bg-color-6.p-4.mb-5(data-aos="fade-left")
      .px-4
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/41.svg")
          .col-lg
            p.mb-0 En cuanto a la carga de la prueba, esta figura procesal determina quién tiene el deber de probar los hechos alegados. El Artículo 167 del Código General del Proceso, establece la regla general, según la cual incumbe a las partes probar el supuesto de hecho de las normas que consagran el efecto jurídico que ellas persiguen. Es decir, quien afirma un hecho debe demostrarlo, mientras que quien lo niega no está obligado a probar su inexistencia, salvo que esté en mejores condiciones para hacerlo, o la Ley así lo exija. 

    .row.mb-5    
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-3.p-4.h-100.j1(data-aos="fade-left")
          p.mb-0 Sin embargo, esta carga no siempre es estática. En algunos casos se aplica la carga dinámica de la prueba, especialmente en procesos donde existe una desigualdad entre las partes. Este principio ha sido desarrollado por la jurisprudencia constitucional y permite trasladar la carga de la prueba a quien se encuentre en mejores condiciones técnicas, jurídicas o económicas, para producirla. Por ejemplo, en un proceso de responsabilidad médica, el paciente afectado puede no tener acceso a la historia clínica completa o al conocimiento técnico necesario, por lo que el juez puede exigir que sea el hospital o el médico quien acredite haber actuado conforme a la lex artis médica.
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/42.png", data-aos="zoom-in")   

    p(data-aos="fade-down") Asimismo, en procesos de consumo, la carga probatoria suele favorecer al consumidor, obligando al proveedor o comerciante a demostrar que el producto o servicio cumplía con las condiciones ofrecidas. Esto refuerza el principio de protección al débil jurídico y garantiza un verdadero acceso a la justicia material.

    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/43.png", data-aos="zoom-in")   

      .col-lg-8
        .bg-color-1.p-4.j1.h-100(data-aos="fade-left")
          p También existen reglas legales que invierten la carga de la prueba por mandato expreso. En casos de discriminación laboral o violencia basada en género, por ejemplo, la legislación y los tratados internacionales ratificados por Colombia, exigen que, una vez demostrados ciertos indicios, sea el presunto agresor o discriminador, quien demuestre que su conducta no fue violatoria de derechos (Gaceta Jurídica, 2014).

          p.mb-0 En suma, los principios que rigen la prueba y el diseño de la carga probatoria, no son simples formalidades procesales, sino garantías para el respeto del debido proceso, la transparencia del juicio y la justicia de la decisión. 

    #t_2_2.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.2] Medios de prueba y procedimiento probatorio 

    .row.mb-5
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") El desarrollo probatorio en el proceso civil colombiano, regulado por la Ley 1564 del 2012, constituye una etapa primordial, pues es el medio a través del cual las partes demuestran los hechos en los que basan sus pretensiones o excepciones. Los medios de prueba son los instrumentos o vías mediante los cuales se busca generar convicción en el juez sobre la verdad de los hechos afirmados. Sin prueba no hay certeza judicial, y sin certeza, no es posible dictar una sentencia ajustada al Derecho.      
        .bg-color-2.p-4.j1(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/44.svg")
            .col-lg
              p.mb-0 El Código General del Proceso, reconoce como principales medios probatorios, los documentos, la confesión, el testimonio, el dictamen pericial, la inspección judicial y los indicios. Cada uno de estos medios posee reglas técnicas que regulan su solicitud, admisión, práctica y valoración (Picó i Junoy, 2008).
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/45.png", data-aos="zoom-in")  

    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-4.mb-3.mb-lg-0  
        figure
          img.img-a.img-t(src="@/assets/curso/temas/46.png", alt="")    
      .col-lg-8
        AcordionA(tipo="b")
          .div(titulo="El documento")
            p Es uno de los medios más comunes y relevantes. Puede ser público o privado. Un documento público es aquel expedido por un funcionario público en ejercicio de sus funciones, como una escritura pública, un registro civil o un certificado notarial, y goza de presunción de autenticidad. El documento privado, en cambio, necesita ser reconocido por la parte a la que se le opone o ser autenticado. Por ejemplo, en un proceso ejecutivo fundado en un pagaré, dicho título valor es un documento privado que deberá cumplir con requisitos de autenticidad y exigibilidad.
          .div(titulo="La confesión")
            p Es la manifestación voluntaria, expresa o tácita, de una parte, sobre hechos que le son adversos y favorables a la contraparte. Tiene alto valor probatorio y puede ser provocada mediante interrogatorio de parte. Por ejemplo, si en una audiencia el demandado admite que no pagó una deuda, aunque alega una justificación posterior, tal afirmación podría constituir confesión y facilitar la decisión del juez.
          .div(titulo="El testimonio")
            p Es la declaración que una persona realiza bajo juramento sobre hechos que le constan directa o indirectamente. Es necesario que el testigo tenga capacidad legal y conocimiento de los hechos. La veracidad, coherencia y precisión de su relato son evaluadas cuidadosamente por el juez. Por ejemplo, en un proceso de responsabilidad civil por accidente, el testimonio de un transeúnte que presenció el hecho puede ser clave para establecer la culpa.                         


    .row.align-items-start.mb-5(data-aos="fade-left") 
      .col-lg-8.mb-3.mb-lg-0  
        AcordionA(tipo="b")
          .div(titulo="El dictamen pericial")
            p Consiste en la opinión técnica, científica o artística, rendida por un perito sobre temas que requieren conocimiento especializado. Es fundamental en procesos complejos, como los de responsabilidad médica, daños estructurales o valoración económica. El perito debe estar debidamente acreditado y su dictamen puede ser controvertido por las partes, mediante objeciones o contra experticias. 
          .div(titulo="La inspección judicial")
            p Permite al juez examinar directamente personas, lugares, cosas, documentos u objetos. Es útil en casos donde la percepción directa del juzgador puede aclarar aspectos relevantes del litigio. Por ejemplo, en un proceso de perturbación a la posesión de un inmueble, el juez puede verificar si realmente existe ocupación indebida o daño visible, además de los linderos del inmueble (Picó i Junoy, 2008).
          .div(titulo="El indicio")
            p Es un medio indirecto de prueba que se obtiene a partir de hechos debidamente probados, de los cuales puede inferirse otro hecho desconocido mediante un proceso lógico y razonado. Por ejemplo, si se acredita que una persona tenía motivos, medios y oportunidad para cometer un acto ilícito, estos hechos podrían constituir indicios graves de su responsabilidad.                         
                                                        
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/47.png", alt="")      

    .bg-full-width.bg-color-7.p-4.mb-5(data-aos="fade-left")
      .px-4
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/48.png")
          .col-lg
            p.mb-0 Todos estos medios deben ser solicitados de manera oportuna en el proceso, y es en la audiencia inicial donde las partes deben practicarlos con claridad, indicando los hechos que buscan demostrar con cada uno. Esta audiencia cumple una función procesal decisiva pues depura el debate, define las pruebas admisibles, resuelve excepciones de mérito, fija los hechos admitidos y controvertidos, y deja listo el proceso para la fase de práctica probatoria.

    p(data-aos="fade-down") La audiencia de instrucción y juzgamiento, por su parte, es el espacio donde se practican efectivamente las pruebas admitidas. Esta etapa está guiada por los principios de:

    .bg-full-width-2.bg-fondo-1.py-4.mb-5
      .px-4.px-md-5
        .row.justify-content-center.align-items-stretch.text-center.mb-4
          .col-lg-4.mb-4(data-aos="zoom-in-up")
            .bg-color-white.p-4.h-100.sha.brounded-sm
              img(src='@/assets/curso/temas/49.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
              h4.mb-4 Oralidad
              p Permite que las pruebas se presenten y discutan en forma directa y verbal ante el juez.
          .col-lg-4.mb-4(data-aos="zoom-in-up")
            .bg-color-white.p-4.h-100.sha.brounded-sm
              img(src='@/assets/curso/temas/50.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
              h4.mb-4 Concentración
              p Exige que todas las pruebas se practiquen en una sola audiencia o en la menor cantidad posible de sesiones, para evitar dilaciones injustificadas. 
          .col-lg-4.mb-4(data-aos="zoom-in-up")
            .bg-color-white.p-4.h-100.sha.brounded-sm
              img(src='@/assets/curso/temas/51.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
              h4.mb-4 Inmediación
              p Garantiza que el juez que conoce el caso, sea quien practique las pruebas y valore directamente su contenido, evitando delegaciones o intermediarios.                            

        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/52.svg")
          .col-lg
            p Es importante resaltar que el incumplimiento de las reglas en la solicitud, admisión o práctica de una prueba, puede acarrear su inadmisión, su pérdida o su ineficacia. Por ejemplo, si una parte no justifica la pertinencia o la conducencia de un testigo, o si no lo cita debidamente, corre el riesgo de que dicha prueba no sea tenida en cuenta.

            p.mb-0 En conclusión, el éxito de un proceso civil depende, en gran medida, de una estrategia probatoria bien diseñada, técnica y legalmente fundada. 

    #t_2_3.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.3] Valoración de la prueba

    p(data-aos="fade-down") La valoración de la prueba representa un momento crucial dentro del proceso judicial, ya que determina la validez de los hechos y sustenta la decisión final del juez.


    .bg-full-width.bg-color-4.mb-5
      .px-4.p-md-5
        .row.justify-content-center.align-items-center 
          .col-lg-8.mb-3.mb-lg-0
            h2.mb-4(data-aos="flip-up") Valoración de la prueba 
            p.mb-4(data-aos="fade-right") En el PDF Valoración de la prueba, se analiza cómo el sistema procesal civil colombiano, exige al juez evaluar las pruebas conforme a la sana crítica, garantizando una apreciación racional, objetiva y motivada, que respete el debido proceso y asegure decisiones judiciales justas y verificables.
            a.anexo.mb-4.bg-white.w-fit(:href="obtenerLink('/downloads/Anexo_2.pdf')" target="_blank")(data-aos="flip-up")
              .anexo__icono(:style="{'background-color': '#FCDFDB'}")
                img(src="@/assets/template/icono-pdf.svg")
              .anexo__texto
                p <strong>Anexo. </strong> Valoración de la prueba 
          .col-lg-4
            figure(data-aos="zoom-in")
              img(src='@/assets/curso/temas/53.png', alt='')   

    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://elibro.net/es/ereader/tecnologicadeloriente/69376?page=48" target="_blank" rel="noopener noreferrer") Cruz Tejada, H. (2011). Nuevas tendencias del derecho probatorio. Universidad de los Andes. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="http://www.secretariasenado.gov.co/senado/basedoc/ley_1564_2012.html" target="_blank" rel="noopener noreferrer") Ley 1564 del 2012. Por medio de la cual se expide el Código General del Proceso y se dictan otras disposiciones. 12 de julio de 2012. D.O. 48.489. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://elibro.net/es/ereader/tecnologicadeloriente/52229?page=18" target="_blank" rel="noopener noreferrer") Abel Lluch, X. (2008). Los poderes del juez civil en materia probatoria. J.M. BOSCH EDITOR. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://elibro.net/es/ereader/tecnologicadeloriente/52269?page=129" target="_blank" rel="noopener noreferrer") Abel Lluch, X. (2008). Objeto y carga de la prueba civil. J.M. BOSCH EDITOR.                                           

            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://ve.scielo.org/scielo.php?script=sci_arttext&pid=S1315-85972008000100006" target="_blank" rel="noopener noreferrer") Herrera Carbuccia, M. R. (2008). La Sentencia. Gaceta Laboral, 14(1), 133-156. 
            p.d-flex.my-4
              img.me-3(src='@/assets/template/book.svg' :style="{'max-width':'16px'}")
              a(href="https://www.salapenaltribunalmedellin.com/images/doctrina/libros01/compendio_de_la_prueba_judicial_i.pdf " target="_blank" rel="noopener noreferrer") Devis Echandía, H. (2000). Compendio de la prueba judicial (Tomo I). Rubinzal-Culzoni Editores.              

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=pxu2Tj3TOhk" target="_blank" rel="noopener noreferrer") Facultad de Derecho. (2020). Derecho Probatorio - Clases de Prueba [video]. 
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=zAo6IPeeRHs" target="_blank" rel="noopener noreferrer") Facultad de Derecho UCO. (2021). Prueba documental en el Código General del Proceso [video]. 
            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=ZmXME74FnkI" target="_blank" rel="noopener noreferrer") Bonet Videos Procesal. (2017). Assessment of proof. Topic 9 "Litigation and Theory of Proof" [video].                            

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema2',
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
