<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in")        
      .col-lg-8
        p(data-aos="fade-down") La comprensión de las diferentes clases de procesos contempladas en el Código General del Proceso, es esencial para la adecuada interpretación y aplicación de las normas procesales en el ejercicio profesional del Derecho. Esta unidad aborda los tipos de procesos judiciales, sus características y estructuras, así como los principios probatorios, la carga de la prueba, los medios de prueba admitidos y su valoración, conforme a los lineamientos normativos. El estudio de estos aspectos permite consolidar una visión integral del proceso como mecanismo que materializa la justicia y garantiza la eficacia de los derechos sustanciales.

        .bg-color-1.p-4.mb-4(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/2.svg")
            .col-lg
              p.mb-0 Al finalizar la unidad, se espera que el estudiante analice las clases de procesos, identifique sus etapas, comprenda la importancia de la prueba en el desarrollo del proceso judicial y valore críticamente los principios que rigen la actividad probatoria. Asimismo, se pretende que aplique estos conocimientos a situaciones hipotéticas que le permitan interpretar y argumentar jurídicamente, con base en el Código General del Proceso.

    p(data-aos="fade-down") La pertinencia de esta unidad radica en que proporciona al estudiante las herramientas necesarias para enfrentar situaciones procesales reales, evaluar las estrategias jurídicas disponibles y tomar decisiones fundamentadas en materia de prueba. El dominio de estas nociones es imprescindible para el litigio, la asesoría jurídica y el diseño de defensas judiciales efectivas.

    p(data-aos="fade-down") La unidad está organizada en torno a cinco ejes. 

    .row.justify-content-center.mb-5  
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/3.svg")
            .col-lg
              h5 Primer eje
              p.mb-0 La clasificación general de los procesos  verbales, ejecutivos, liquidatorios y jurisdicción voluntaria.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-down")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/4.svg")
            .col-lg
              h5 Segundo eje
              p.mb-0 La estructura interna de los procesos y sus etapas.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-right")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/5.svg")
            .col-lg
              h5 Tercer eje
              p.mb-0 Los principios que orientan la actividad probatoria.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-left")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/6.svg")
            .col-lg
              h5 Cuarto eje 
              p.mb-0 Los medios de prueba reconocidos por la Ley.
      .col-lg-4.mb-3 
        .bg-color-7.p-2.j1.h-100(data-aos="fade-right")
          .row.align-items-center    
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/7.svg")
            .col-lg
              h5 Quinto eje
              p.mb-0 Los criterios de valoración probatoria.
                                                                      
    .row           
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-3.p-4.j1.h-100(data-aos="fade-left")
          p Las actividades previstas incluyen la resolución de casos hipotéticos, análisis normativos, ejercicios de argumentación jurídica y participación en foros académicos.

          p.mb-0 Se espera del estudiante una actitud analítica y proactiva en el desarrollo de los contenidos, así como el cumplimiento riguroso de las actividades académicas. Se recomienda el estudio detallado del Código General del Proceso y la participación activa en los espacios de discusión, con el fin de fortalecer las competencias necesarias para intervenir de manera eficiente, en los diferentes escenarios del Derecho Procesal. 
      .col-lg-4 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/8.png", data-aos="zoom-in")             
</template>
